# MC Wrapper — Native-Core Purpur Server Host

A minimal-RAM Android wrapper for running a Minecraft 1.16.5 Purpur server
on memory-constrained (~800MB) non-rooted devices. All process management,
telemetry, and crash handling is implemented in native C++ via JNI; Kotlin
is a thin UI/service shell only.

## Project layout

```
MCWrapper/
├── build.gradle                          (project root)
├── settings.gradle
├── gradle.properties
└── app/
    ├── build.gradle                      (NDK/CMake config)
    ├── proguard-rules.pro
    └── src/main/
        ├── AndroidManifest.xml
        ├── cpp/
        │   ├── CMakeLists.txt
        │   └── native-server-core.cpp    (JNI core: launcher + telemetry + crash handler)
        ├── java/com/example/mcwrapper/
        │   ├── NativeBridge.kt           (external fun declarations only)
        │   ├── MainActivity.kt           (dark UI, polls native telemetry/console)
        │   └── ServerForegroundService.kt(wake lock + starts native server)
        └── res/
            ├── layout/activity_main.xml
            └── values/{colors,themes,strings}.xml
```

## 1. NDK setup in Android Studio

1. **SDK Manager → SDK Tools** tab → check "NDK (Side by side)" and "CMake",
   click Apply. Note the installed NDK version string (e.g. `26.3.11579264`).
2. Open `app/build.gradle` and set `ndkVersion` to match exactly what you
   installed.
3. Android Studio will auto-detect `externalNativeBuild { cmake { path ... } }`
   in `app/build.gradle` and configure the CMake build the first time you sync.
4. `abiFilters "arm64-v8a"` is set to build a single ABI — add
   `"armeabi-v7a"` too only if you need to support older 32-bit devices;
   every extra ABI roughly doubles native library size on disk/in the APK.

## 2. The one thing you must solve before this actually runs a JVM

Stock, non-rooted Android **does not ship a `java` binary**, and Android 10+
enforces W^X on app-private storage — you cannot download a JRE into
`filesDir`, `chmod +x` it, and `execve()` it; the OS will refuse to run it.

`native-server-core.cpp`'s `spawn_jvm_process()` is written exactly to the
architecture you specified (fork + exec with the exact G1GC flags), but it
needs a **path to a `java` executable Android is willing to execute**. Two
practical ways to get one on a non-rooted device:

- **Recommended:** obtain a JRE built for Android (e.g. from a Termux-style
  distribution), and place its native binaries under
  `app/src/main/jniLibs/arm64-v8a/` renamed with a `lib*.so` prefix/suffix
  (e.g. `libjava.so`). APK installation marks `nativeLibraryDir` executable
  and it is exempt from the W^X restriction that blocks `filesDir`. Point
  `ServerForegroundService.javaBinPath()` at
  `applicationInfo.nativeLibraryDir + "/libjava.so"` (already wired up that
  way in the sample).
- **Alternative:** embed the JVM as a library and call `JNI_CreateJavaVM`
  in-process instead of exec-ing a separate process — avoids the exec
  restriction entirely but is a larger undertaking (effectively embedding
  a JVM-in-a-JVM).

Stage `purpur-1.16.5.jar` (and the server's working directory / EULA file)
under `getExternalFilesDir(null)` — see the path helpers at the top of
`ServerForegroundService.kt`.

## 3. Permissions

Declared in `AndroidManifest.xml`:
- `WAKE_LOCK`, `FOREGROUND_SERVICE`, `FOREGROUND_SERVICE_SPECIAL_USE`
- `KILL_BACKGROUND_PROCESSES` (see note below)
- `POST_NOTIFICATIONS` (Android 13+, required for the foreground notification)
- `INTERNET`

**Note on `killBackgroundProcesses()`:** on modern Android this API is
restricted for third-party apps — a normal app can generally only affect
processes associated with its own package/UID, not arbitrary other apps.
It's still wired in per your spec (`MainActivity.killBackgroundProcesses()`,
called right before `NativeBridge.startServer()`), but don't expect it to
behave like a root-level "kill everything else" button.

## 4. Runtime data flow

1. `MainActivity` → tap Start → `killBackgroundProcesses()` →
   starts `ServerForegroundService` (foreground + `PARTIAL_WAKE_LOCK`).
2. Service calls `NativeBridge.startServer(javaBin, jarPath, workDir)`.
3. Native code installs `sigaction` handlers, `fork()`s, `execvp()`s java
   with the exact G1GC flag set in the child, and spawns two detached
   `std::thread`s in the parent: one reading the child's stdout/stderr into
   a 50-line ring buffer, one sampling `/proc/meminfo`,
   `scaling_cur_freq`, and `/sys/class/thermal/thermal_zone*/temp` every 5s
   into a capped `std::deque` history.
4. `MainActivity` polls `getTelemetryData()` / `getConsoleBuffer()` every 2s
   on the UI thread (cheap native string calls, no JVM-side buffering).
5. Stop button → `stopServer()` → native code writes `"stop\n"` to the
   child's stdin (graceful Minecraft shutdown), waits up to 10s, then
   escalates to `SIGTERM` → `SIGKILL` if needed.
6. If the native process ever segfaults/aborts, the installed signal
   handlers write a pre-serialized snapshot of the last ~20 telemetry
   samples and the last 50 console lines to
   `/data/data/com.example.mcwrapper/files/telemetry_crash.txt` before
   re-raising the signal.

## 5. Before your first build

- Generate launcher icons via Android Studio's **Image Asset Studio**
  (`res/mipmap/ic_launcher*`) — none are checked in here.
- Replace `com.example.mcwrapper` with your real applicationId/package if
  desired (update it in `build.gradle`, `AndroidManifest.xml`, and all
  Kotlin/C++ package references and JNI symbol names together).
