package com.example.mcwrapper

import android.app.ActivityManager
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import androidx.appcompat.app.AppCompatActivity
import com.example.mcwrapper.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private val pollHandler = Handler(Looper.getMainLooper())
    private var polling = false

    private val pollRunnable = object : Runnable {
        override fun run() {
            // Reads are cheap native calls — safe to poll on the UI thread
            // at a modest interval. All heavy lifting stays in C++.
            binding.textTelemetry.text = formatTelemetry(NativeBridge.getTelemetryData())
            binding.textConsole.text = NativeBridge.getConsoleBuffer()

            val running = NativeBridge.isRunning()
            binding.btnStart.isEnabled = !running
            binding.btnStop.isEnabled = running

            if (polling) pollHandler.postDelayed(this, 2000)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.btnStart.setOnClickListener { onStartClicked() }
        binding.btnStop.setOnClickListener { onStopClicked() }
    }

    private fun onStartClicked() {
        // Free up whatever background headroom Android will grant us right
        // before we ask the JVM child process for a 512MB heap.
        killBackgroundProcesses()

        val serviceIntent = Intent(this, ServerForegroundService::class.java).apply {
            action = ServerForegroundService.ACTION_START
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            startForegroundService(serviceIntent)
        } else {
            startService(serviceIntent)
        }
    }

    private fun onStopClicked() {
        val serviceIntent = Intent(this, ServerForegroundService::class.java).apply {
            action = ServerForegroundService.ACTION_STOP
        }
        startService(serviceIntent)
    }

    /**
     * Requires the KILL_BACKGROUND_PROCESSES permission. Note: since Android
     * puts privacy limits on this API, a normal (non-system, non-device-owner)
     * app can generally only affect processes tied to its own package/UID —
     * it is NOT a general-purpose "close all other apps" button on modern
     * Android. It's included here because it's cheap, harmless, and matches
     * the requested architecture.
     */
    private fun killBackgroundProcesses() {
        val am = getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        try {
            am.killBackgroundProcesses(packageName)
        } catch (_: SecurityException) {
            // Permission not granted or restricted by OEM — non-fatal.
        }
    }

    private fun formatTelemetry(raw: String): String {
        if (raw == "no_data") return "Waiting for telemetry…"
        val fields = raw.split(";").associate {
            val (k, v) = it.split("=", limit = 2)
            k to v
        }
        val memTotalMb = (fields["mem_total_kb"]?.toLongOrNull() ?: 0) / 1024
        val memAvailMb = (fields["mem_avail_kb"]?.toLongOrNull() ?: 0) / 1024
        val memFreeMb  = (fields["mem_free_kb"]?.toLongOrNull() ?: 0) / 1024
        val cpuMhz     = (fields["cpu_freq_khz"]?.toLongOrNull() ?: 0) / 1000
        val tempC      = fields["temp_c"] ?: "?"

        return buildString {
            append("RAM: $memAvailMb MB avail / $memTotalMb MB total (free: $memFreeMb MB)\n")
            append("CPU: $cpuMhz MHz\n")
            append("Temp: $tempC °C")
        }
    }

    override fun onResume() {
        super.onResume()
        polling = true
        pollHandler.post(pollRunnable)
    }

    override fun onPause() {
        polling = false
        pollHandler.removeCallbacks(pollRunnable)
        super.onPause()
    }
}
