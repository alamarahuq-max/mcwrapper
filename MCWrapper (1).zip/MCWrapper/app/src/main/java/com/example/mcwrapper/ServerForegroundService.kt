package com.example.mcwrapper

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import androidx.core.app.NotificationCompat
import java.io.File

class ServerForegroundService : Service() {

    private var wakeLock: PowerManager.WakeLock? = null

    companion object {
        const val CHANNEL_ID = "mc_server_channel"
        const val NOTIF_ID = 1001
        const val ACTION_START = "com.example.mcwrapper.action.START"
        const val ACTION_STOP = "com.example.mcwrapper.action.STOP"

        // Adjust these to wherever you actually staged the JRE binary and jar.
        // See native-server-core.cpp header comment re: exec restrictions.
        fun javaBinPath(ctx: Context) = File(ctx.applicationInfo.nativeLibraryDir, "libjava.so").absolutePath
        fun jarPath(ctx: Context) = File(ctx.getExternalFilesDir(null), "purpur-1.16.5.jar").absolutePath
        fun workDir(ctx: Context) = ctx.getExternalFilesDir(null)?.absolutePath ?: ctx.filesDir.absolutePath
    }

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> {
                NativeBridge.stopServer()
                releaseWakeLock()
                stopForeground(STOP_FOREGROUND_REMOVE)
                stopSelf()
                return START_NOT_STICKY
            }
            else -> {
                startForeground(NOTIF_ID, buildNotification("Starting server…"))
                acquireWakeLock()

                // Native call spawns its own detached pthreads for the child
                // process reader + telemetry loop, so we don't need a Kotlin
                // background thread here — just fire and forget.
                val started = NativeBridge.startServer(
                    javaBinPath(this),
                    jarPath(this),
                    workDir(this)
                )

                updateNotification(if (started) "Server running" else "Failed to start server")
                return START_STICKY
            }
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        NativeBridge.stopServer()
        releaseWakeLock()
        super.onDestroy()
    }

    private fun acquireWakeLock() {
        if (wakeLock?.isHeld == true) return
        val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
        wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "MCWrapper::ServerWakeLock").apply {
            setReferenceCounted(false)
            acquire(12 * 60 * 60 * 1000L /* 12h safety timeout, renew via service restarts */)
        }
    }

    private fun releaseWakeLock() {
        wakeLock?.let { if (it.isHeld) it.release() }
        wakeLock = null
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID, "Minecraft Server", NotificationManager.IMPORTANCE_LOW
            ).apply { description = "Keeps the Purpur server process alive" }
            val nm = getSystemService(NotificationManager::class.java)
            nm.createNotificationChannel(channel)
        }
    }

    private fun buildNotification(text: String): Notification {
        val stopIntent = Intent(this, ServerForegroundService::class.java).apply { action = ACTION_STOP }
        val stopPending = PendingIntent.getService(
            this, 0, stopIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("Purpur Server")
            .setContentText(text)
            .setSmallIcon(android.R.drawable.ic_media_play)
            .addAction(android.R.drawable.ic_media_pause, "Stop", stopPending)
            .setOngoing(true)
            .build()
    }

    private fun updateNotification(text: String) {
        val nm = getSystemService(NotificationManager::class.java)
        nm.notify(NOTIF_ID, buildNotification(text))
    }
}
