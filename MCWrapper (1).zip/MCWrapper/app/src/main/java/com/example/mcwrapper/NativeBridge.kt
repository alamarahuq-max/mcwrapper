package com.example.mcwrapper

/**
 * Thin JNI bridge. Deliberately holds no state, no logic, no buffers —
 * every one of those lives in native-server-core.cpp so the JVM heap
 * on the wrapper-app side stays tiny and GC-quiet.
 */
object NativeBridge {

    init {
        System.loadLibrary("native-server-core")
    }

    /**
     * @param javaBinPath absolute path to a `java` executable that Android
     *   is actually allowed to execve() — e.g. a path under this app's
     *   nativeLibraryDir if you ship a JRE as jniLibs. See the header
     *   comment in native-server-core.cpp for why this can't just be "java".
     * @param jarPath absolute path to purpur-1.16.5.jar
     * @param workDir directory the server should run in (world data, etc.)
     */
    external fun startServer(javaBinPath: String, jarPath: String, workDir: String): Boolean

    external fun stopServer(): Boolean

    external fun isRunning(): Boolean

    /** Returns a single semicolon-delimited line of the latest sample. */
    external fun getTelemetryData(): String

    /** Returns up to the last 50 lines of server stdout/stderr, newline-joined. */
    external fun getConsoleBuffer(): String
}
