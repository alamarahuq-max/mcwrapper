// native-server-core.cpp
//
// Native core for the Minecraft Purpur server wrapper.
// All process management, telemetry, and crash handling lives here so the
// Kotlin/JVM side of the *wrapper app* stays a thin, GC-light UI shell.
//
// NOTE ON JVM LAUNCHING (read this before you ship):
// Stock non-rooted Android has no `java` binary and, since Android 10,
// enforces W^X on app-private storage (/data/data/<pkg>/files) — you cannot
// chmod +x a downloaded ELF there and execve() it. The two viable options:
//   1) Ship a JRE build (e.g. a Termux-built OpenJDK for Android) whose native
//      binaries are placed under app/src/main/jniLibs/<abi>/ as libXXX.so files
//      (renamed, since APK installers mark nativeLibraryDir executable and
//      exempt it from W^X). Point kJavaBinPath at that installed path.
//   2) Use a JVM embedded as a shared library and call its API in-process
//      (JNI_CreateJavaVM) instead of exec-ing a separate `java` process —
//      more work, but avoids the exec restriction entirely.
// This file implements the fork/exec architecture exactly as specified,
// with the binary path passed in from Kotlin so you can point it at whichever
// of the above you choose.

#include <jni.h>
#include <android/log.h>

#include <atomic>
#include <thread>
#include <mutex>
#include <deque>
#include <vector>
#include <string>
#include <sstream>
#include <fstream>
#include <cstdio>
#include <cstring>
#include <cstdlib>
#include <csignal>
#include <ctime>

#include <unistd.h>
#include <fcntl.h>
#include <sys/wait.h>
#include <sys/types.h>
#include <dirent.h>

#define LOG_TAG "NativeServerCore"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, LOG_TAG, __VA_ARGS__)
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, LOG_TAG, __VA_ARGS__)

// ---------------------------------------------------------------------------
// Config
// ---------------------------------------------------------------------------
static constexpr int   kTelemetryIntervalSec   = 5;
static constexpr size_t kTelemetryHistoryCap    = 512;   // ~42 min of history at 5s
static constexpr size_t kConsoleLineCap         = 50;
static const char*     kCrashDumpPath           = "/data/data/com.example.mcwrapper/files/telemetry_crash.txt";

// ---------------------------------------------------------------------------
// Telemetry data model
// ---------------------------------------------------------------------------
struct TelemetrySnapshot {
    long long timestamp_ms   = 0;
    long mem_total_kb        = 0;
    long mem_available_kb    = 0;
    long mem_free_kb         = 0;
    long cpu_freq_khz        = 0;
    double temp_celsius      = 0.0;
};

static std::mutex               g_telemetry_mutex;
static std::deque<TelemetrySnapshot> g_telemetry_history;   // bounded ring buffer

static std::mutex               g_console_mutex;
static std::deque<std::string>  g_console_lines;            // bounded ring buffer (last 50)

static std::atomic<bool>        g_telemetry_running{false};
static std::atomic<bool>        g_server_running{false};
static std::thread              g_telemetry_thread;
static std::thread              g_reader_thread;

static pid_t                    g_child_pid   = -1;
static int                      g_child_stdin_fd = -1;   // write end, to send "stop" gracefully

// ---------------------------------------------------------------------------
// /proc + /sys parsing helpers
// ---------------------------------------------------------------------------

// Parses /proc/meminfo for MemTotal / MemAvailable / MemFree (all in kB).
static void read_mem_info(long &total_kb, long &avail_kb, long &free_kb) {
    total_kb = avail_kb = free_kb = 0;
    std::ifstream file("/proc/meminfo");
    if (!file.is_open()) return;

    std::string key;
    long value;
    std::string unit;
    while (file >> key >> value >> unit) {
        if (key == "MemTotal:")      total_kb = value;
        else if (key == "MemAvailable:") avail_kb = value;
        else if (key == "MemFree:")  free_kb = value;
        if (total_kb && avail_kb && free_kb) break;
    }
}

// Reads current CPU frequency (kHz) of cpu0.
static long read_cpu_freq_khz() {
    std::ifstream file("/sys/devices/system/cpu/cpu0/cpufreq/scaling_cur_freq");
    long khz = 0;
    if (file.is_open()) file >> khz;
    return khz;
}

// Scans /sys/class/thermal/thermal_zone* for the first readable temperature.
// Values are usually in milli-Celsius; some SoCs report raw Celsius already —
// we heuristically divide by 1000 only when the raw value looks like m°C.
static double read_temperature_c() {
    DIR *dir = opendir("/sys/class/thermal");
    if (!dir) return 0.0;

    double result = 0.0;
    struct dirent *entry;
    while ((entry = readdir(dir)) != nullptr) {
        std::string name(entry->d_name);
        if (name.rfind("thermal_zone", 0) != 0) continue;

        std::string path = "/sys/class/thermal/" + name + "/temp";
        std::ifstream tf(path);
        if (!tf.is_open()) continue;

        long raw = 0;
        tf >> raw;
        if (raw == 0) continue;

        double celsius = (raw > 1000) ? (raw / 1000.0) : static_cast<double>(raw);
        // Sanity bound — ignore obviously bogus zones (e.g. 0 or > 150C)
        if (celsius > 0.0 && celsius < 150.0) {
            result = celsius;
            break; // first sane reading is good enough for a lightweight monitor
        }
    }
    closedir(dir);
    return result;
}

static long long now_ms() {
    struct timespec ts{};
    clock_gettime(CLOCK_REALTIME, &ts);
    return static_cast<long long>(ts.tv_sec) * 1000LL + ts.tv_nsec / 1000000LL;
}

// ---------------------------------------------------------------------------
// Crash handling — flush buffered telemetry + console before the process dies
// ---------------------------------------------------------------------------
// NOTE: fopen/fprintf/fclose are not strictly on the POSIX async-signal-safe
// list. In practice, on Bionic, a best-effort single-threaded flush like this
// works reliably for a last-gasp diagnostic dump, but if you need hard
// guarantees prefer pre-formatting the buffer BEFORE the signal and using
// only write(2) inside the handler. We do a hybrid: data is pre-serialized
// into a flat buffer continuously; the handler just writes that flat buffer.

static char g_crash_buffer[64 * 1024];
static std::mutex g_crash_buffer_mutex;

static void refresh_crash_buffer_locked() {
    // Called periodically (from the telemetry thread) so the buffer is
    // always "recent enough" to be useful if we crash a moment later.
    std::ostringstream oss;
    oss << "=== Native crash dump (last known telemetry) ===\n";
    {
        std::lock_guard<std::mutex> lk(g_telemetry_mutex);
        int count = 0;
        for (auto it = g_telemetry_history.rbegin();
             it != g_telemetry_history.rend() && count < 20; ++it, ++count) {
            oss << "[t=" << it->timestamp_ms << "] "
                << "memTotal=" << it->mem_total_kb << "kB "
                << "memAvail=" << it->mem_available_kb << "kB "
                << "memFree=" << it->mem_free_kb << "kB "
                << "cpuFreq=" << it->cpu_freq_khz << "kHz "
                << "temp=" << it->temp_celsius << "C\n";
        }
    }
    oss << "=== Last console lines ===\n";
    {
        std::lock_guard<std::mutex> lk(g_console_mutex);
        for (auto &line : g_console_lines) oss << line << "\n";
    }

    std::lock_guard<std::mutex> lk(g_crash_buffer_mutex);
    std::string s = oss.str();
    size_t n = std::min(s.size(), sizeof(g_crash_buffer) - 1);
    memcpy(g_crash_buffer, s.data(), n);
    g_crash_buffer[n] = '\0';
}

extern "C" void crash_signal_handler(int sig) {
    // Keep this handler minimal. We already have the data pre-formatted.
    FILE *f = fopen(kCrashDumpPath, "w");
    if (f) {
        fprintf(f, "Native crash caught, signal=%d\n", sig);
        fwrite(g_crash_buffer, 1, strlen(g_crash_buffer), f);
        fflush(f);
        fclose(f);
    }
    // Re-raise default behavior so the OS still records a tombstone/ANR as usual.
    signal(sig, SIG_DFL);
    raise(sig);
}

static void install_crash_handlers() {
    struct sigaction sa{};
    sa.sa_handler = crash_signal_handler;
    sigemptyset(&sa.sa_mask);
    sa.sa_flags = 0;

    sigaction(SIGSEGV, &sa, nullptr);
    sigaction(SIGABRT, &sa, nullptr);
    sigaction(SIGFPE,  &sa, nullptr);
    sigaction(SIGILL,  &sa, nullptr);
    sigaction(SIGBUS,  &sa, nullptr);
}

// ---------------------------------------------------------------------------
// Telemetry thread
// ---------------------------------------------------------------------------
static void telemetry_loop() {
    LOGI("Telemetry thread started");
    while (g_telemetry_running.load(std::memory_order_relaxed)) {
        TelemetrySnapshot snap;
        snap.timestamp_ms = now_ms();
        read_mem_info(snap.mem_total_kb, snap.mem_available_kb, snap.mem_free_kb);
        snap.cpu_freq_khz = read_cpu_freq_khz();
        snap.temp_celsius = read_temperature_c();

        {
            std::lock_guard<std::mutex> lk(g_telemetry_mutex);
            g_telemetry_history.push_back(snap);
            if (g_telemetry_history.size() > kTelemetryHistoryCap) {
                g_telemetry_history.pop_front();
            }
        }

        refresh_crash_buffer_locked();

        for (int i = 0; i < kTelemetryIntervalSec * 10 &&
                        g_telemetry_running.load(std::memory_order_relaxed); ++i) {
            std::this_thread::sleep_for(std::chrono::milliseconds(100));
        }
    }
    LOGI("Telemetry thread stopped");
}

// ---------------------------------------------------------------------------
// Child process stdout/stderr reader thread
// ---------------------------------------------------------------------------
static int g_child_stdout_fd = -1;

static void reader_loop() {
    LOGI("Console reader thread started");
    char buf[4096];
    std::string partial_line;

    while (g_server_running.load(std::memory_order_relaxed)) {
        ssize_t n = read(g_child_stdout_fd, buf, sizeof(buf) - 1);
        if (n > 0) {
            buf[n] = '\0';
            partial_line += buf;

            size_t pos;
            while ((pos = partial_line.find('\n')) != std::string::npos) {
                std::string line = partial_line.substr(0, pos);
                partial_line.erase(0, pos + 1);

                std::lock_guard<std::mutex> lk(g_console_mutex);
                g_console_lines.push_back(line);
                if (g_console_lines.size() > kConsoleLineCap) {
                    g_console_lines.pop_front();
                }
            }
        } else if (n == 0) {
            // EOF — child closed stdout, process has likely exited.
            break;
        } else {
            if (errno == EINTR) continue;
            break;
        }
    }
    LOGI("Console reader thread stopped");
}

// ---------------------------------------------------------------------------
// JVM process launcher (fork + exec)
// ---------------------------------------------------------------------------
static bool spawn_jvm_process(const std::string &java_bin,
                               const std::string &jar_path,
                               const std::string &work_dir) {
    int stdout_pipe[2];
    int stdin_pipe[2];
    if (pipe(stdout_pipe) != 0) { LOGE("pipe(stdout) failed: %s", strerror(errno)); return false; }
    if (pipe(stdin_pipe)  != 0) { LOGE("pipe(stdin) failed: %s", strerror(errno));  return false; }

    pid_t pid = fork();
    if (pid < 0) {
        LOGE("fork() failed: %s", strerror(errno));
        return false;
    }

    if (pid == 0) {
        // ---- Child process ----
        dup2(stdin_pipe[0], STDIN_FILENO);
        dup2(stdout_pipe[1], STDOUT_FILENO);
        dup2(stdout_pipe[1], STDERR_FILENO);

        close(stdin_pipe[0]);  close(stdin_pipe[1]);
        close(stdout_pipe[0]); close(stdout_pipe[1]);

        if (!work_dir.empty()) {
            if (chdir(work_dir.c_str()) != 0) {
                // Non-fatal — continue with whatever CWD we have.
            }
        }

        // Exact memory-tuned flags as specified.
        std::vector<std::string> args = {
            java_bin,
            "-Xms512M", "-Xmx512M",
            "-XX:+UseG1GC",
            "-XX:MaxGCPauseMillis=100",
            "-XX:+UnlockExperimentalVMOptions",
            "-XX:G1NewSizePercent=20",
            "-XX:G1MaxNewSizePercent=30",
            "-XX:G1HeapRegionSize=2M",
            "-XX:G1ReservePercent=10",
            "-XX:InitiatingHeapOccupancyPercent=20",
            "-XX:+AlwaysPreTouch",
            "-XX:+UseStringDeduplication",
            "-XX:+OptimizeStringConcat",
            "-XX:+UseCompressedOops",
            "-Xss256k",
            "-jar", jar_path,
            "nogui"
        };

        std::vector<char *> argv;
        argv.reserve(args.size() + 1);
        for (auto &a : args) argv.push_back(const_cast<char *>(a.c_str()));
        argv.push_back(nullptr);

        execvp(java_bin.c_str(), argv.data());
        // execvp only returns on failure.
        _exit(127);
    }

    // ---- Parent process ----
    close(stdin_pipe[0]);
    close(stdout_pipe[1]);

    g_child_pid       = pid;
    g_child_stdin_fd  = stdin_pipe[1];
    g_child_stdout_fd = stdout_pipe[0];

    // Non-blocking-ish reads are nicer, but a dedicated blocking reader
    // thread is simpler and cheap enough for one child process.
    LOGI("Spawned JVM process, pid=%d", pid);
    return true;
}

// ---------------------------------------------------------------------------
// JNI exports
// ---------------------------------------------------------------------------
extern "C" JNIEXPORT jboolean JNICALL
Java_com_example_mcwrapper_NativeBridge_startServer(
        JNIEnv *env, jobject /*thiz*/,
        jstring jJavaBin, jstring jJarPath, jstring jWorkDir) {

    if (g_server_running.load()) {
        LOGI("startServer() called but server already running");
        return JNI_FALSE;
    }

    const char *java_bin_c = env->GetStringUTFChars(jJavaBin, nullptr);
    const char *jar_path_c = env->GetStringUTFChars(jJarPath, nullptr);
    const char *work_dir_c = env->GetStringUTFChars(jWorkDir, nullptr);

    std::string java_bin(java_bin_c);
    std::string jar_path(jar_path_c);
    std::string work_dir(work_dir_c);

    env->ReleaseStringUTFChars(jJavaBin, java_bin_c);
    env->ReleaseStringUTFChars(jJarPath, jar_path_c);
    env->ReleaseStringUTFChars(jWorkDir, work_dir_c);

    install_crash_handlers();

    if (!spawn_jvm_process(java_bin, jar_path, work_dir)) {
        return JNI_FALSE;
    }

    g_server_running.store(true);
    g_reader_thread = std::thread(reader_loop);

    if (!g_telemetry_running.load()) {
        g_telemetry_running.store(true);
        g_telemetry_thread = std::thread(telemetry_loop);
    }

    return JNI_TRUE;
}

extern "C" JNIEXPORT jboolean JNICALL
Java_com_example_mcwrapper_NativeBridge_stopServer(JNIEnv * /*env*/, jobject /*thiz*/) {
    if (!g_server_running.load()) return JNI_FALSE;

    // Try a graceful shutdown first: Minecraft/Purpur listens for "stop" on stdin.
    if (g_child_stdin_fd >= 0) {
        const char *cmd = "stop\n";
        write(g_child_stdin_fd, cmd, strlen(cmd));
    }

    // Give it a grace window to shut down cleanly before escalating.
    int waited_ms = 0;
    const int grace_ms = 10000;
    int status = 0;
    while (waited_ms < grace_ms) {
        pid_t r = waitpid(g_child_pid, &status, WNOHANG);
        if (r == g_child_pid) break;
        std::this_thread::sleep_for(std::chrono::milliseconds(200));
        waited_ms += 200;
    }

    if (waitpid(g_child_pid, &status, WNOHANG) != g_child_pid) {
        LOGI("Graceful stop timed out, sending SIGTERM");
        kill(g_child_pid, SIGTERM);
        std::this_thread::sleep_for(std::chrono::milliseconds(1500));
        if (waitpid(g_child_pid, &status, WNOHANG) != g_child_pid) {
            LOGI("Escalating to SIGKILL");
            kill(g_child_pid, SIGKILL);
            waitpid(g_child_pid, &status, 0);
        }
    }

    g_server_running.store(false);
    g_telemetry_running.store(false);

    if (g_reader_thread.joinable()) g_reader_thread.join();
    if (g_telemetry_thread.joinable()) g_telemetry_thread.join();

    if (g_child_stdin_fd >= 0)  { close(g_child_stdin_fd);  g_child_stdin_fd = -1; }
    if (g_child_stdout_fd >= 0) { close(g_child_stdout_fd); g_child_stdout_fd = -1; }
    g_child_pid = -1;

    return JNI_TRUE;
}

extern "C" JNIEXPORT jboolean JNICALL
Java_com_example_mcwrapper_NativeBridge_isRunning(JNIEnv * /*env*/, jobject /*thiz*/) {
    return g_server_running.load() ? JNI_TRUE : JNI_FALSE;
}

extern "C" JNIEXPORT jstring JNICALL
Java_com_example_mcwrapper_NativeBridge_getTelemetryData(JNIEnv *env, jobject /*thiz*/) {
    std::ostringstream oss;
    std::lock_guard<std::mutex> lk(g_telemetry_mutex);
    if (g_telemetry_history.empty()) {
        oss << "no_data";
    } else {
        const TelemetrySnapshot &s = g_telemetry_history.back();
        oss << "ts=" << s.timestamp_ms
            << ";mem_total_kb=" << s.mem_total_kb
            << ";mem_avail_kb=" << s.mem_available_kb
            << ";mem_free_kb=" << s.mem_free_kb
            << ";cpu_freq_khz=" << s.cpu_freq_khz
            << ";temp_c=" << s.temp_celsius;
    }
    return env->NewStringUTF(oss.str().c_str());
}

extern "C" JNIEXPORT jstring JNICALL
Java_com_example_mcwrapper_NativeBridge_getConsoleBuffer(JNIEnv *env, jobject /*thiz*/) {
    std::ostringstream oss;
    std::lock_guard<std::mutex> lk(g_console_mutex);
    for (auto &line : g_console_lines) {
        oss << line << "\n";
    }
    return env->NewStringUTF(oss.str().c_str());
}
