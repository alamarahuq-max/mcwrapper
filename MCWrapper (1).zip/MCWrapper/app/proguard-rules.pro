# Keep JNI-facing methods — their names are looked up by the native library
# via Java_com_example_mcwrapper_NativeBridge_* symbol matching.
-keep class com.example.mcwrapper.NativeBridge { *; }
